---
title: Cursor Handoff — bookmarklets/internet_display_info.html — Bookmarklet Unification
document_id: HANDOFF-bm-unify-internet-display-info
date: 2026-06-30
project: AAR-TC CVRMLS Matrix Bookmarklet
---

Replace the entire contents of `bookmarklets/internet_display_info.html` with the file below. This is a full-file replacement, not a partial edit — the existing file contains Lennar-specific logic that this version removes entirely.

## Change 1 — Replace full file contents

**Add** (replacing the entire current contents of `bookmarklets/internet_display_info.html`):

```html
<!DOCTYPE html>
<html>
<head>
  <title>Matrix — Internet Display Info</title>
  <style>
    body { font-family: sans-serif; max-width: 600px; margin: 60px auto; padding: 0 20px; color: #333; }
    h2 { margin-bottom: 4px; }
    .tab-label { font-size: 12px; font-weight: bold; letter-spacing: 0.08em; text-transform: uppercase; color: #1a73e8; margin-bottom: 16px; }
    p { margin-top: 4px; color: #666; font-size: 14px; }
    a.bookmarklet { display: inline-block; margin: 20px 0; padding: 14px 28px; background: #1a73e8; color: white; text-decoration: none; border-radius: 6px; font-size: 16px; font-weight: bold; }
    a.bookmarklet:hover { background: #1558b0; }
    .instructions { background: #f5f5f5; border-left: 4px solid #1a73e8; padding: 16px 20px; border-radius: 4px; font-size: 14px; line-height: 1.8; margin-top: 8px; }
    .static-note { background: #e8f5e9; border-left: 4px solid #34a853; padding: 12px 16px; border-radius: 4px; font-size: 13px; margin-top: 20px; line-height: 1.7; }
    .note { font-size: 12px; color: #888; margin-top: 24px; }
  </style>
</head>
<body>

  <div class="tab-label">Tab 12 — Internet Display Info</div>
  <h2>Fill Internet Display Info</h2>
  <p>Universal — fully static, no clipboard needed. This reflects MLS-wide policy, not a builder preference, so the constant is genuinely universal — confirmed against the live file.</p>

  <a class="bookmarklet" href="javascript:(function()%20%7Bfunction%20setField(id%2C%20value)%20%7Bvar%20el%20%3D%20document.getElementById(id)%3Bif%20(el)%20%7B%20el.value%20%3D%20value%3B%20%7D%7DsetField('Input_227'%2C%20'1')%3BsetField('Input_228'%2C%20'1')%3BsetField('Input_229'%2C%20'1')%3BsetField('Input_230'%2C%20'1')%3B%7D)()%3B">Fill Internet Display Info</a>

  <div class="instructions">
    <strong>To install:</strong><br>
    1. Make bookmarks bar visible — Cmd+Shift+B<br>
    2. Drag the blue button to the bookmarks bar<br>
    3. Place in the <strong>Matrix — New</strong>, <strong>Matrix — Tax ID</strong>, or <strong>Matrix — Copy</strong> folder (this tab behaves the same on all three paths)<br><br>
    <strong>To use:</strong><br>
    1. Navigate to the Internet Display Info tab in Matrix<br>
    2. Click the bookmark — no clipboard copy needed
  </div>

  <div class="static-note">
    <strong>Hardcoded values — universal, every listing:</strong><br>
    Internet Display → Yes<br>
    Address Display → Yes<br>
    Comments/Reviews → Yes<br>
    AVM → Yes
  </div>

  <div class="note">AAR-TC-CVRMLS-BM-SRC-001 | Source: CVRMLS_Bookmarklet_Source.md</div>

</body>
</html>
```

No other changes to `bookmarklets/internet_display_info.html`.

Do not commit yet. Changes for additional files follow in separate handoffs.
