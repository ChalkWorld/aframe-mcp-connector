---
title: Cursor Handoff — bookmarklets/showing_instructions.html — Bookmarklet Unification
document_id: HANDOFF-bm-unify-showing-instructions
date: 2026-06-30
project: AAR-TC CVRMLS Matrix Bookmarklet
---

Replace the entire contents of `bookmarklets/showing_instructions.html` with the file below. This is a full-file replacement, not a partial edit — the existing file contains Lennar-specific logic that this version removes entirely.

## Change 1 — Replace full file contents

**Add** (replacing the entire current contents of `bookmarklets/showing_instructions.html`):

```html
<!DOCTYPE html>
<html>
<head>
  <title>Matrix — Showing Instructions</title>
  <style>
    body { font-family: sans-serif; max-width: 600px; margin: 60px auto; padding: 0 20px; color: #333; }
    h2 { margin-bottom: 4px; }
    .tab-label { font-size: 12px; font-weight: bold; letter-spacing: 0.08em; text-transform: uppercase; color: #1a73e8; margin-bottom: 16px; }
    p { margin-top: 4px; color: #666; font-size: 14px; }
    a.bookmarklet { display: inline-block; margin: 20px 0; padding: 14px 28px; background: #1a73e8; color: white; text-decoration: none; border-radius: 6px; font-size: 16px; font-weight: bold; }
    a.bookmarklet:hover { background: #1558b0; }
    .instructions { background: #f5f5f5; border-left: 4px solid #1a73e8; padding: 16px 20px; border-radius: 4px; font-size: 14px; line-height: 1.8; margin-top: 8px; }
    .payload-label { font-size: 13px; font-weight: bold; color: #555; margin: 28px 0 6px 0; }
    .payload { background: #1e1e1e; color: #d4d4d4; padding: 16px 20px; border-radius: 4px; font-size: 12px; font-family: monospace; white-space: pre; margin-bottom: 8px; }
    .note { font-size: 12px; color: #888; margin-top: 24px; }
  </style>
</head>
<body>

  <div class="tab-label">Tab 10 — Showing Instructions</div>
  <h2>Fill Showing Instructions</h2>
  <p>Universal — fully payload-driven, including the Sentrilock zero-pad quirk. No builder branch; Lennar statics (Accompany Show, Appt Required, Showing Instr 2, LockBox Type) are resolved by the session before the payload is generated, same as the standard vacancy-driven defaults.</p>

  <a class="bookmarklet" href="javascript:(function()%20%7Bfunction%20setField(id%2C%20value)%20%7Bvar%20el%20%3D%20document.getElementById(id)%3Bif%20(el)%20%7B%20el.value%20%3D%20value%3B%20%7D%7Dfunction%20setCheck(id%2C%20checked)%20%7Bvar%20el%20%3D%20document.getElementById(id)%3Bif%20(el)%20%7B%20el.checked%20%3D%20checked%3B%20%7D%7Dnavigator.clipboard.readText().then(function(text)%20%7Bvar%20d%20%3D%20JSON.parse(text).showing%3BsetCheck('Input_722_AS'%2C%20d.accompany_show%20%7C%7C%20false)%3BsetCheck('Input_722_AR'%2C%20d.appt_required%20%7C%7C%20false)%3BsetField('Input_136'%2C%20d.showing_instr_2%20%7C%7C%20%22%22)%3BsetField('Input_333'%2C%20d.lockbox_type%20%7C%7C%20%22%22)%3Bif%20(d.sentrilock_serial)%20%7Bvar%20serial%20%3D%20String(d.sentrilock_serial).padStart(8%2C%20'0')%3BsetField('Input_732'%2C%20serial)%3B%7DsetField('Input_138'%2C%20d.additional_instructions%20%7C%7C%20%22%22)%3B%7D).catch(function(e)%20%7Balert('Showing%20Instructions%20error%3A%20'%20%2B%20e.message)%3B%7D)%3B%7D)()%3B">Fill Showing Instructions</a>

  <div class="instructions">
    <strong>To install:</strong><br>
    1. Make bookmarks bar visible — Cmd+Shift+B<br>
    2. Drag the blue button to the bookmarks bar<br>
    3. Place in the <strong>Matrix — New</strong>, <strong>Matrix — Tax ID</strong>, or <strong>Matrix — Copy</strong> folder<br><br>
    <strong>To use:</strong><br>
    1. Copy the full JSON payload to clipboard<br>
    2. Navigate to the Showing Instructions tab in Matrix<br>
    3. Click the bookmark — every field populates from the payload
  </div>

  <div class="payload-label">Payload reference — showing key</div>
  <div class="payload">"showing": {
  "accompany_show":          false,
  "appt_required":           true,
  "showing_instr_2":         "NLCS",   // or "LBGD" if vacant (standard listings)
  "lockbox_type":            "",       // "" for Lennar (no lockbox); Sentrilock for standard
  "sentrilock_serial":       "",       // 7-digit serial — bookmarklet zero-pads to 8 chars
  "additional_instructions": ""
}</div>

  <p style="font-size:12px;color:#888;margin-top:4px;">Resolved by the session per builder before the payload is generated. Lennar: Accompany Show always false, Appt Required always true, Showing Instr 2 always "NLCS", LockBox Type always blank — see <code>Lennar_Bookmarklet_Customization.md</code>. Standard: Appt Required always true, LockBox Type always Sentrilock, Showing Instr 2 defaults to "NLCS" but switches to "LBGD" if the Cognito intake form marks the property vacant — see <code>New_Seller_Side_Session_Protocol.md</code>.</p>

  <div class="note">AAR-TC-CVRMLS-BM-SRC-001 | Source: CVRMLS_Bookmarklet_Source.md</div>

</body>
</html>
```

No other changes to `bookmarklets/showing_instructions.html`.

Do not commit yet. Changes for additional files follow in separate handoffs.
