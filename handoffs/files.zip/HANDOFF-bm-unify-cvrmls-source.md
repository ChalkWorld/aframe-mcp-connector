---
title: Cursor Handoff — docs/cvrmls/CVRMLS_Bookmarklet_Source.md — Bookmarklet Unification
document_id: HANDOFF-bm-unify-cvrmls-source
date: 2026-06-30
project: AAR-TC CVRMLS Matrix Bookmarklet
---

Apply the changes below surgically to `docs/cvrmls/CVRMLS_Bookmarklet_Source.md`. Do not modify anything not listed here. This collapses every tab's "Non-Lennar Variant" / "Lennar Variant" pair into a single universal function — the corrected architecture means there is no longer a meaningful distinction at the bookmarklet layer. Builder-specific values are resolved entirely session-side now; see the companion handoff for `docs/lennar/Lennar_Bookmarklet_Customization.md` for where those values now live.

## Change 1 — TAB 1 Listing Info: remove Lennar reference, confirm header framing

**Find:**

```markdown
## TAB 1 — Listing Info
```

**Replace with:**

```markdown
## TAB 1 — Listing Info

**Single universal function — no builder branch.** All location fields (county/city, area, zip, subdivision, neighborhood, schools, post office) and all listing-behavior statics (Delayed Show, New/Resale, Year Built Desc, Expire Date, SqFt Source) are resolved to final values by the session before the payload is generated, using the relevant builder's reference doc. The bookmarklet reads `payload.listing.*` exclusively and has no knowledge of which builder it came from.
```

## Change 2 — TAB 1 Listing Info: full function body replacement

**Find:**

```javascript
      setField('Input_162', '12/31/2026'); // Expire Date = Master Listing Agreement expiry
      setField('Input_97',  '04');         // SqFt Source = Per Builder

      // Step 5: Dynamic listing fields from payload
      setField('Input_31',  d.list_price);
      setField('Input_160', d.list_date);
      setField('Input_849', d.type);
      setField('Input_850', d.attached_yn);

      // PID
      if (path === "new") {
        setField('Input_99', 'TBD');
      }
      // taxid path: Input_99 pre-populated — skip

      // Step 6: Location — New path only (pre-filled on taxid and copy paths)
      if (path === "new") {
        setField('Input_34', d.street_num);
        setField('Input_35', d.street_dir || "");
        setField('Input_36', d.street_name);
        setField('Input_37', d.street_suffix);
      }

      // Step 7: Property details — always write
      setField('Input_44',  d.year_built);
      setField('Input_48',  d.rooms);
      setField('Input_49',  d.levels);
      setField('Input_622', d.lot);
      setField('Input_47',  d.bedrooms);

      // Square footage
      setField('Input_879', d.sqft_above_finished   || "0");
      setField('Input_882', d.sqft_below_finished   || "0");
      setField('Input_880', d.sqft_above_unfinished || "0");
      setField('Input_883', d.sqft_below_unfinished || "0");

    })();

  }).catch(function(e) {
    alert('Bookmarklet error — could not read clipboard: ' + e.message);
  });

})();
```

**Replace with:**

```javascript
      setField('Input_32',  d.delayed_show);
      setField('Input_42',  d.new_resale);
      setField('Input_45',  d.year_built_desc);
      setField('Input_162', d.expire_date);
      setField('Input_97',  d.sqft_source || "01");

      // Step 5: Dynamic listing fields from payload
      setField('Input_31',  d.list_price);
      setField('Input_160', d.list_date);
      setField('Input_849', d.type);
      setField('Input_850', d.attached_yn);

      // PID
      if (path === "new") {
        setField('Input_99', d.pid || 'TBD');
      }
      // taxid path: Input_99 pre-populated — skip

      // Step 6: Street number/name/suffix — New path only (pre-filled on taxid/copy paths)
      // Street direction always writes regardless of path
      setField('Input_35', d.street_dir || "");
      if (path === "new") {
        setField('Input_34', d.street_num);
        setField('Input_36', d.street_name);
        setField('Input_37', d.street_suffix);
      }

      // Step 7: Property details — gated to non-taxid (pre-populated on taxid path)
      if (path !== "taxid") {
        setField('Input_44',  d.year_built);
        setField('Input_48',  d.rooms);
        setField('Input_49',  d.levels);
        setField('Input_622', d.lot);
        setField('Input_47',  d.bedrooms);
      }

      // Square footage
      setField('Input_879', d.sqft_above_finished   || "0");
      setField('Input_882', d.sqft_below_finished   || "0");
      setField('Input_880', d.sqft_above_unfinished || "0");
      setField('Input_883', d.sqft_below_unfinished || "0");

    })();

  }).catch(function(e) {
    alert('Bookmarklet error — could not read clipboard: ' + e.message);
  });

})();
```

## Change 3 — TAB 3 Bath Info: collapse two variants into one

**Find:**

```markdown
### Bath Info — Lennar Variant

Same structure. No Lennar-specific static values for Bath Info — all bath data is listing-specific. This variant is functionally identical to the non-Lennar variant. Kept as a separate entry for consistency and in case Lennar bath defaults are ever established.

```javascript
// Lennar variant — functionally identical to non-Lennar for Bath Info
// All values come from payload.bath — no Lennar hardcodes for this tab
// See non-Lennar variant above
```
```

**Delete**

## Change 4 — TAB 3 Bath Info: rename header

**Find:**

```markdown
### Bath Info — Non-Lennar Variant
```

**Replace with:**

```markdown
### Bath Info — Universal

Already fully payload-driven — no builder logic ever existed for this tab.
```

## Change 5 — TAB 5 General Info: replace full function, unmerge isLennar gate

**Find:**

```javascript
    var payload = JSON.parse(text);
    var d = payload.general;
    var path = payload.path || "new";

    // Always write
    setField('Input_249', d.model_available   || "0");  // Model Available
    setField('Input_94',  d.waterfront        || "N");  // Waterfront
    setField('Input_246', d.assd_improvement  || "0");  // Assd Improvement — confirmed Input_246; write "0" on both paths (does not pre-populate even on Tax ID path)
```

**Replace with:**

```javascript
    var payload = JSON.parse(text);
    var d = payload.general;
    var path = payload.path || "new";

    // Always write — fully payload-driven, no builder gate
    setField('Input_249', d.model_available  || "0");  // Model Available
    setField('Input_94',  d.waterfront       || "N");  // Waterfront
    setField('Input_248', d.assd_improvement || "0");  // Assd Improvement — confirmed Input_248;
                                                          // session resolves "0" for Lennar (never
                                                          // pre-populates either path) or omits the
                                                          // key for standard taxid listings where
                                                          // Matrix pre-populates the value
```

## Change 6 — TAB 5 General Info: fix path-gated fields, drop Input_246 from "always write" block

**Find:**

```javascript
    // Dynamic fields — path-dependent
    if (path === "new") {
      setField('Input_95', d.acres || "");
      setField('Input_100', d.legal || "");  // Legal Description
    }
    // taxid path: Acres and Legal pre-populated — skip
```

**Replace with:**

```javascript
    // New path only — pre-populated from tax record on taxid path
    if (path === "new") {
      setField('Input_246', d.tax_year || "0");  // Tax Year
      setField('Input_95',  d.acres    || "");   // Acres
      setField('Input_100', d.legal    || "");   // Legal Description
    }
    // taxid path: Tax Year, Acres, Legal Description pre-populated — skip all three
```

## Change 7 — TAB 5 General Info: update tab summary note above the code block

**Find:**

```markdown
## TAB 5 — General Info

**Lennar static fields:** Waterfront (`N`), Model Available (`0`/No), Disclosures (`NOTREQ`), Lead Disclosure (`NOTREQ`), Assd Improvement (`0`)
**Dynamic (New path only):** Acres, Legal Description (`TBD`)
**Tax ID path:** Acres, Legal pre-populate — skip both. Assd Improvement does NOT pre-populate — write `0` on both paths.
```

**Replace with:**

```markdown
## TAB 5 — General Info

**Single universal function — no builder branch.** Built from the existing non-Lennar variant, which was already fully payload-driven with confirmed value lists for both checkbox groups (Disclosures, 12 options; Lead Disclosure, 5 options). The only change is removing the `isLennar` gate that previously wrapped Assd Improvement (`Input_248`) — it is now unconditional, with the session resolving the value per builder (Lennar: always `"0"`; standard taxid listings: omit the key so Matrix's pre-populated value is left untouched).
```

## Change 8 — TAB 6 Remarks: collapse two variants into one

**Find:**

```markdown
### Remarks — Lennar Variant

Functionally identical to non-Lennar. Copyright Agreement hardcoded in both. Kept as separate entry for consistency.

```javascript
// Lennar variant — functionally identical to non-Lennar for Remarks
// Copyright Agreement hardcoded to "1" (Yes) in both variants
// See non-Lennar variant above
```
```

**Delete**

## Change 9 — TAB 6 Remarks: rename header

**Find:**

```markdown
### Remarks — Non-Lennar Variant
```

**Replace with:**

```markdown
### Remarks — Universal

Copyright Agreement is a genuine MLS-wide constant, not a builder assumption — confirmed against the live launcher file this session.
```

## Change 10 — TAB 7 Fee Info: full function replacement, no Lennar hardcodes

**Find:**

```javascript
    var d = JSON.parse(text).fee;

    // HOA and Membership — always Yes for properties with HOA
    setField('Input_109', '1');  // HOA/Condo = Yes
    setField('Input_112', '1');  // Membership Required = Yes

    // Additional HOA
    setField('Input_719', d.addl_hoa || "0");

    // Fee details
    setField('Input_110', d.fee_amount      || "");
    setField('Input_113', d.fee_period      || "");
    setField('Input_705', d.management_firm || "");

    // Additional fee fields
    setField('Input_115', d.addl_fee_amount || "");
    setField('Input_117', d.addl_fee_desc   || "");

    // Fee Desc checkbox group — uncheck all, then check selected
    var feeDescIds = ['01','02','03','04','05'];
    feeDescIds.forEach(function(v) { setCheck('Input_111_' + v, false); });
    (d.fee_desc || []).forEach(function(v) { setCheck('Input_111_' + v, true); });

    // Fee Includes checkbox group — uncheck all, then check selected
    var feeInclIds = ['26','19','01','25','18','03','04','05','06','07',
                      '08','27','28','09','10','11','29','12','22','20',
                      '13','14','15','23','21','17'];
    feeInclIds.forEach(function(v) { setCheck('Input_576_' + v, false); });
    (d.fee_includes || []).forEach(function(v) { setCheck('Input_576_' + v, true); });

    // Allow Onsite — uncheck all (non-Lennar may vary; set from payload if needed)
    var allowOnsiteIds = ['1','4','5','6','7','8'];
    allowOnsiteIds.forEach(function(v) { setCheck('Input_116_' + v, false); });
    (d.allow_onsite || []).forEach(function(v) { setCheck('Input_116_' + v, true); });

  }).catch(function(e) {
    alert('Bookmarklet error — could not read clipboard: ' + e.message);
  });

})();
```

**Replace with:**

```javascript
    var d = JSON.parse(text).fee;

    // HOA / Membership — fully payload-driven
    setField('Input_109', d.hoa_condo);
    setField('Input_112', d.membership_required);

    // Fee Desc checkbox group (5 options) — uncheck all, then check from payload
    var feeDescIds = ['01','02','03','04','05'];
    feeDescIds.forEach(function(v) { setCheck('Input_111_' + v, false); });
    (d.fee_desc || []).forEach(function(v) { setCheck('Input_111_' + v, true); });

    // Allow Onsite checkbox group (6 options) — uncheck all, then check from payload
    var allowOnsiteIds = ['1','4','5','6','7','8'];
    allowOnsiteIds.forEach(function(v) { setCheck('Input_116_' + v, false); });
    (d.allow_onsite || []).forEach(function(v) { setCheck('Input_116_' + v, true); });

    // Community/listing-variable fields — always payload-driven
    setField('Input_719', d.addl_hoa        || "0");
    setField('Input_110', d.fee_amount      || "");
    setField('Input_113', d.fee_period      || "");
    setField('Input_705', d.management_firm || "");
    setField('Input_115', d.addl_fee_amount || "");
    setField('Input_117', d.addl_fee_desc   || "");

    // Fee Includes checkbox group (26 options) — uncheck all, then check from payload
    var feeInclIds = ['26','19','01','25','18','03','04','05','06','07',
                      '08','27','28','09','10','11','29','12','22','20',
                      '13','14','15','23','21','17'];
    feeInclIds.forEach(function(v) { setCheck('Input_576_' + v, false); });
    (d.fee_includes || []).forEach(function(v) { setCheck('Input_576_' + v, true); });

  }).catch(function(e) {
    alert('Fee Info error: ' + e.message);
  });

})();
```

## Change 11 — TAB 7 Fee Info: delete the now-obsolete Lennar Variant section

**Find:**

```markdown
### Fee Info — Lennar Variant

Lennar statics hardcoded (HOA Yes, Membership Yes, Fee Desc = Community Association, Allow Onsite = all unchecked). Community-variable fields still come from clipboard.
```

**Delete** — including the JavaScript code block that follows this header (the Lennar-variant function), up to but not including the next `---` section divider before TAB 8.

## Change 12 — TAB 7 Fee Info: rename remaining header and update summary

**Find:**

```markdown
### Fee Info — Non-Lennar Variant
```

**Replace with:**

```markdown
### Fee Info — Universal

No builder branch. HOA/Membership/Fee Desc/Allow Onsite are resolved by the session before the payload is generated, identically to community-variable fields like Fee Amount — the bookmarklet treats every field on this tab the same way.
```

## Change 13 — TAB 9 Agent/Office Info: collapse two variants, add clipboard read

**Find:**

```markdown
### Agent/Office Info — Non-Lennar Variant

```javascript
(function() {

  function setField(id, value) {
    var el = document.getElementById(id);
    if (el) { el.value = value; }
  }

  // List Agent Code (Input_159) — always pre-filled, never touch
  setField('Input_170', '');    // Co-List Agent Code — blank
  setField('Input_163', 'ER'); // Type = Exclusive Right (non-Lennar default)
  setField('Input_164', '0');  // Limited Rep = No (non-Lennar default)
  // Input_853 (Listing Override / Office Email) — skip, leave blank

})();
```

---

### Agent/Office Info — Lennar Variant

```javascript
(function() {

  function setField(id, value) {
    var el = document.getElementById(id);
    if (el) { el.value = value; }
  }

  // List Agent Code (Input_159) — always pre-filled, never touch
  setField('Input_170', '');    // Co-List Agent Code — blank
  setField('Input_163', 'MO'); // Type = MLS Only
  setField('Input_164', '1');  // Limited Rep = Yes

})();
```
```

**Replace with:**

```markdown
### Agent/Office Info — Universal

No builder branch. Previously the Lennar variant had no clipboard read at all (fully static); this tab is now fully payload-driven via the `agent_office` key, matching every other tab's pattern.

```javascript
(function() {

  function setField(id, value) {
    var el = document.getElementById(id);
    if (el) { el.value = value; }
  }

  navigator.clipboard.readText().then(function(text) {

    var d = JSON.parse(text).agent_office || {};

    // List Agent Code (Input_159) — always pre-filled by Matrix, never touch
    setField('Input_170', d.co_list_agent_code || '');
    setField('Input_163', d.type);
    setField('Input_164', d.limited_rep);
    // Input_853 (Listing Override / Office Email) — skip, leave blank

  }).catch(function(e) {
    alert('Agent/Office Info error: ' + e.message);
  });

})();
```
```

## Change 14 — TAB 10 Showing Instructions: delete the now-obsolete Lennar Variant section

**Find:**

```markdown
### Showing Instructions — Lennar Variant

```javascript
(function() {

  function setField(id, value) {
    var el = document.getElementById(id);
    if (el) { el.value = value; }
  }
  function setCheck(id, checked) {
    var el = document.getElementById(id);
    if (el) { el.checked = checked; }
  }

  navigator.clipboard.readText().then(function(text) {

    var d = JSON.parse(text).showing;

    // Lennar static fields
    setCheck('Input_722_AS', false);   // Accompany Show = unchecked
    setCheck('Input_722_AR', true);    // Appt Required = checked
    setField('Input_136', 'NLCS');     // Showing Instr 2 = No LB Call Showing Service
    setField('Input_333', '');         // LockBox Type = blank (no LB for Lennar)
    // Input_137 (Supra Serial) — skip
    // Input_732 (Sentrilock Serial) — skip

    // Dynamic — from payload
    setField('Input_138', d.additional_instructions || "");

  }).catch(function(e) {
    alert('Bookmarklet error — could not read clipboard: ' + e.message);
  });

})();
```
```

**Delete**

## Change 15 — TAB 10 Showing Instructions: rename remaining header

**Find:**

```markdown
### Showing Instructions — Non-Lennar Variant
```

**Replace with:**

```markdown
### Showing Instructions — Universal

No builder branch. The existing non-Lennar variant already correctly handled standard-listing variation (Sentrilock zero-padding, vacancy-driven defaults) — confirmed against the live file this session; only the Lennar static block in the now-deleted Lennar variant needed to go.
```

## Change 16 — TAB 8 Owner Info: add full universal section (new content — this tab previously had no entry in this file; Lennar-only logic lived entirely in `Lennar_Bookmarklet_Customization.md`)

**Find:**

```markdown
## TAB 9 — Agent/Office Info
```

**Replace with:**

```markdown
## TAB 8 — Owner Info

No builder branch. Previously fully static for Lennar with no payload key at all; now fully payload-driven via the `owner` key. **Open design question, not resolved here:** does the session always resolve `owner_name` into the payload when an override is needed (Lennar or otherwise), making the taxid-skip logic for this one field unconditional rather than builder-gated — or does Owner Info override behavior stay Lennar-only in practice? Flagged for a session-level decision.

```javascript
(function() {

  function setField(id, value) {
    var el = document.getElementById(id);
    if (el) { el.value = value; }
  }
  function setCheck(id, checked) {
    var el = document.getElementById(id);
    if (el) { el.checked = checked; }
  }

  navigator.clipboard.readText().then(function(text) {

    var d = JSON.parse(text).owner || {};

    // Owner Name — unconditional write whenever present in payload, regardless of path.
    // If the session omits owner_name, Matrix's tax-record value on the taxid path is
    // left untouched.
    if (d.owner_name !== undefined) {
      setField('Input_118', d.owner_name);
    }

    setField('Input_119', d.occupant_name || "");
    setField('Input_606', d.occupied_by   || "");
    setField('Input_124', d.owner_agent   || "0");
    setField('Input_707', d.agent_related_to_seller || "0");

    var ownedByIds = ['02','03','04','06','07','08','01'];
    ownedByIds.forEach(function(v) { setCheck('Input_120_' + v, false); });
    if (d.owned_by) { setCheck('Input_120_' + d.owned_by, true); }

    var possessionIds = ['01','02','06','03','04','05'];
    possessionIds.forEach(function(v) { setCheck('Input_121_' + v, false); });
    if (d.possession) { setCheck('Input_121_' + d.possession, true); }

  }).catch(function(e) {
    alert('Owner Info error: ' + e.message);
  });

})();
```

---

## TAB 9 — Agent/Office Info
```

No other changes to `docs/cvrmls/CVRMLS_Bookmarklet_Source.md`.

Do not commit yet. Changes for additional files follow in separate handoffs.
