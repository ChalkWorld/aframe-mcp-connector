---
title: Cursor Handoff — bookmarklets/bath_info.html — Bookmarklet Unification
document_id: HANDOFF-bm-unify-bath-info
date: 2026-06-30
project: AAR-TC CVRMLS Matrix Bookmarklet
---

Replace the entire contents of `bookmarklets/bath_info.html` with the file below. This is a full-file replacement, not a partial edit — the existing file contains Lennar-specific logic that this version removes entirely.

## Change 1 — Replace full file contents

**Add** (replacing the entire current contents of `bookmarklets/bath_info.html`):

```html
<!DOCTYPE html>
<html>
<head>
  <title>Matrix — Bath Info</title>
  <style>
    body { font-family: sans-serif; max-width: 600px; margin: 60px auto; padding: 0 20px; color: #333; }
    h2 { margin-bottom: 4px; }
    .tab-label { font-size: 12px; font-weight: bold; letter-spacing: 0.08em; text-transform: uppercase; color: #1a73e8; margin-bottom: 16px; }
    p { margin-top: 4px; color: #666; font-size: 14px; }
    a.bookmarklet { display: inline-block; margin: 20px 0; padding: 14px 28px; background: #1a73e8; color: white; text-decoration: none; border-radius: 6px; font-size: 16px; font-weight: bold; }
    a.bookmarklet:hover { background: #1558b0; }
    .instructions { background: #f5f5f5; border-left: 4px solid #1a73e8; padding: 16px 20px; border-radius: 4px; font-size: 14px; line-height: 1.8; margin-top: 8px; }
    .payload-label { font-size: 13px; font-weight: bold; color: #555; margin: 28px 0 6px 0; }
    .payload { background: #1e1e1e; color: #d4d4d4; padding: 16px 20px; border-radius: 4px; font-size: 12px; font-family: monospace; white-space: pre; margin-bottom: 8px; }
    .note { font-size: 12px; color: #888; margin-top: 24px; }
  </style>
</head>
<body>

  <div class="tab-label">Tab 3 — Bath Info</div>
  <h2>Fill Bath Info</h2>
  <p>Universal — reads bath data from clipboard payload. No builder-specific logic; this tab was already fully payload-driven.</p>

  <a class="bookmarklet" href="javascript:(function()%20%7Bfunction%20setField(id%2C%20value)%20%7Bvar%20el%20%3D%20document.getElementById(id)%3Bif%20(el)%20%7B%20el.value%20%3D%20value%3B%20%7D%7Dnavigator.clipboard.readText().then(function(text)%20%7Bvar%20d%20%3D%20JSON.parse(text).bath%3BsetField('Input_57'%2C%20d.basement.desc)%3BsetField('Input_61'%2C%20d.basement.full)%3BsetField('Input_65'%2C%20d.basement.half)%3BsetField('Input_58'%2C%20d.level1.desc)%3BsetField('Input_62'%2C%20d.level1.full)%3BsetField('Input_66'%2C%20d.level1.half)%3BsetField('Input_59'%2C%20d.level2.desc)%3BsetField('Input_63'%2C%20d.level2.full)%3BsetField('Input_67'%2C%20d.level2.half)%3BsetField('Input_60'%2C%20d.level3.desc)%3BsetField('Input_64'%2C%20d.level3.full)%3BsetField('Input_68'%2C%20d.level3.half)%3BsetField('Input_737'%2C%20d.level4.desc)%3BsetField('Input_738'%2C%20d.level4.full)%3BsetField('Input_739'%2C%20d.level4.half)%3B%7D).catch(function(e)%20%7Balert('Bookmarklet%20error%20%E2%80%94%20could%20not%20read%20clipboard%3A%20'%20%2B%20e.message)%3B%7D)%3B%7D)()%3B">Fill Bath Info</a>

  <div class="instructions">
    <strong>To install:</strong><br>
    1. Make bookmarks bar visible — Cmd+Shift+B<br>
    2. Drag the blue button to the bookmarks bar<br>
    3. Place in the <strong>Matrix — New</strong>, <strong>Matrix — Tax ID</strong>, or <strong>Matrix — Copy</strong> folder (this tab behaves the same on all three paths)<br><br>
    <strong>To use:</strong><br>
    1. Copy the full JSON payload to clipboard<br>
    2. Navigate to the Bath Info tab in Matrix<br>
    3. Click the bookmark — fields populate instantly
  </div>

  <div class="payload-label">Payload reference — bath key</div>
  <div class="payload">"bath": {
  "basement": { "desc": "",   "full": "0", "half": "0" },
  "level1":   { "desc": "",   "full": "0", "half": "1" },
  "level2":   { "desc": "TS", "full": "2", "half": "0" },
  "level3":   { "desc": "",   "full": "0", "half": "0" },
  "level4":   { "desc": "",   "full": "0", "half": "0" }
}</div>

  <div class="note">AAR-TC-CVRMLS-BM-SRC-001 | Source: CVRMLS_Bookmarklet_Source.md</div>

</body>
</html>
```

No other changes to `bookmarklets/bath_info.html`.

Do not commit yet. Changes for additional files follow in separate handoffs.
