---
title: Cursor Handoff — bookmarklets/fee_info.html — Bookmarklet Unification
document_id: HANDOFF-bm-unify-fee-info
date: 2026-06-30
project: AAR-TC CVRMLS Matrix Bookmarklet
---

Replace the entire contents of `bookmarklets/fee_info.html` with the file below. This is a full-file replacement, not a partial edit — the existing file contains Lennar-specific logic that this version removes entirely.

## Change 1 — Replace full file contents

**Add** (replacing the entire current contents of `bookmarklets/fee_info.html`):

```html
<!DOCTYPE html>
<html>
<head>
  <title>Matrix — Fee Info</title>
  <style>
    body { font-family: sans-serif; max-width: 600px; margin: 60px auto; padding: 0 20px; color: #333; }
    h2 { margin-bottom: 4px; }
    .tab-label { font-size: 12px; font-weight: bold; letter-spacing: 0.08em; text-transform: uppercase; color: #1a73e8; margin-bottom: 16px; }
    p { margin-top: 4px; color: #666; font-size: 14px; }
    a.bookmarklet { display: inline-block; margin: 20px 0; padding: 14px 28px; background: #1a73e8; color: white; text-decoration: none; border-radius: 6px; font-size: 16px; font-weight: bold; }
    a.bookmarklet:hover { background: #1558b0; }
    .instructions { background: #f5f5f5; border-left: 4px solid #1a73e8; padding: 16px 20px; border-radius: 4px; font-size: 14px; line-height: 1.8; margin-top: 8px; }
    .payload-label { font-size: 13px; font-weight: bold; color: #555; margin: 28px 0 6px 0; }
    .payload { background: #1e1e1e; color: #d4d4d4; padding: 16px 20px; border-radius: 4px; font-size: 12px; font-family: monospace; white-space: pre; overflow-x: auto; margin-bottom: 8px; }
    .note { font-size: 12px; color: #888; margin-top: 24px; }
  </style>
</head>
<body>

  <div class="tab-label">Tab 7 — Fee Info</div>
  <h2>Fill Fee Info</h2>
  <p>Universal — fully payload-driven. No builder branch; HOA/Membership/Fee Desc/Allow Onsite are resolved by the session before the payload is generated, identically to community-variable fields like Fee Amount.</p>

  <a class="bookmarklet" href="javascript:(function()%20%7Bfunction%20setField(id%2C%20value)%20%7Bvar%20el%20%3D%20document.getElementById(id)%3Bif%20(el)%20%7B%20el.value%20%3D%20value%3B%20%7D%7Dfunction%20setCheck(id%2C%20checked)%20%7Bvar%20el%20%3D%20document.getElementById(id)%3Bif%20(el)%20%7B%20el.checked%20%3D%20checked%3B%20%7D%7Dnavigator.clipboard.readText().then(function(text)%20%7Bvar%20d%20%3D%20JSON.parse(text).fee%3BsetField('Input_109'%2C%20d.hoa_condo)%3BsetField('Input_112'%2C%20d.membership_required)%3Bvar%20feeDescIds%20%3D%20%5B'01'%2C'02'%2C'03'%2C'04'%2C'05'%5D%3BfeeDescIds.forEach(function(v)%20%7B%20setCheck('Input_111_'%20%2B%20v%2C%20false)%3B%20%7D)%3B(d.fee_desc%20%7C%7C%20%5B%5D).forEach(function(v)%20%7B%20setCheck('Input_111_'%20%2B%20v%2C%20true)%3B%20%7D)%3Bvar%20allowOnsiteIds%20%3D%20%5B'1'%2C'4'%2C'5'%2C'6'%2C'7'%2C'8'%5D%3BallowOnsiteIds.forEach(function(v)%20%7B%20setCheck('Input_116_'%20%2B%20v%2C%20false)%3B%20%7D)%3B(d.allow_onsite%20%7C%7C%20%5B%5D).forEach(function(v)%20%7B%20setCheck('Input_116_'%20%2B%20v%2C%20true)%3B%20%7D)%3BsetField('Input_719'%2C%20d.addl_hoa%20%7C%7C%20%220%22)%3BsetField('Input_110'%2C%20d.fee_amount%20%7C%7C%20%22%22)%3BsetField('Input_113'%2C%20d.fee_period%20%7C%7C%20%22%22)%3BsetField('Input_705'%2C%20d.management_firm%20%7C%7C%20%22%22)%3BsetField('Input_115'%2C%20d.addl_fee_amount%20%7C%7C%20%22%22)%3BsetField('Input_117'%2C%20d.addl_fee_desc%20%7C%7C%20%22%22)%3Bvar%20feeInclIds%20%3D%20%5B'26'%2C'19'%2C'01'%2C'25'%2C'18'%2C'03'%2C'04'%2C'05'%2C'06'%2C'07'%2C'08'%2C'27'%2C'28'%2C'09'%2C'10'%2C'11'%2C'29'%2C'12'%2C'22'%2C'20'%2C'13'%2C'14'%2C'15'%2C'23'%2C'21'%2C'17'%5D%3BfeeInclIds.forEach(function(v)%20%7B%20setCheck('Input_576_'%20%2B%20v%2C%20false)%3B%20%7D)%3B(d.fee_includes%20%7C%7C%20%5B%5D).forEach(function(v)%20%7B%20setCheck('Input_576_'%20%2B%20v%2C%20true)%3B%20%7D)%3B%7D).catch(function(e)%20%7Balert('Fee%20Info%20error%3A%20'%20%2B%20e.message)%3B%7D)%3B%7D)()%3B">Fill Fee Info</a>

  <div class="instructions">
    <strong>To install:</strong><br>
    1. Make bookmarks bar visible — Cmd+Shift+B<br>
    2. Drag the blue button to the bookmarks bar<br>
    3. Place in the <strong>Matrix — New</strong>, <strong>Matrix — Tax ID</strong>, or <strong>Matrix — Copy</strong> folder<br><br>
    <strong>To use:</strong><br>
    1. Copy the full JSON payload to clipboard<br>
    2. Navigate to the Fee Info tab in Matrix<br>
    3. Click the bookmark — every field populates from the payload, including HOA/Membership/Fee Desc/Allow Onsite
  </div>

  <div class="payload-label">Payload reference — fee key</div>
  <div class="payload">"fee": {
  "hoa_condo":            "1",
  "membership_required":  "1",
  "fee_desc":              ["01"],          // checkbox values — see field map for full 5-option list
  "allow_onsite":          [],              // checkbox values — see field map for full 6-option list
  "addl_hoa":             "0",
  "fee_amount":           "800.00",
  "fee_period":           "YR",             // "MO", "QU", or "YR"
  "management_firm":      "ACS West Management",
  "addl_fee_amount":      "",
  "addl_fee_desc":        "",
  "fee_includes":          ["19","01","25","10","14","15"]
}</div>

  <p style="font-size:12px;color:#888;margin-top:4px;">Resolved by the session per builder before the payload is generated — see <code>Lennar_Bookmarklet_Customization.md</code> / <code>Lennar_Bookmarklet_Build_Notes.md</code> for the per-community Lennar table.</p>

  <div class="note">AAR-TC-CVRMLS-BM-SRC-001 | Source: CVRMLS_Bookmarklet_Source.md</div>

</body>
</html>
```

No other changes to `bookmarklets/fee_info.html`.

Do not commit yet. Changes for additional files follow in separate handoffs.
