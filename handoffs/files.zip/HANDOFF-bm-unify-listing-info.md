---
title: Cursor Handoff — bookmarklets/listing_info.html — Bookmarklet Unification
document_id: HANDOFF-bm-unify-listing-info
date: 2026-06-30
project: AAR-TC CVRMLS Matrix Bookmarklet
---

Replace the entire contents of `bookmarklets/listing_info.html` with the file below. This is a full-file replacement, not a partial edit — the existing file contains Lennar-specific logic that this version removes entirely.

## Change 1 — Replace full file contents

**Add** (replacing the entire current contents of `bookmarklets/listing_info.html`):

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Listing Info Bookmarklet</title>
  <style>
    body { font-family: sans-serif; padding: 40px; background: #f5f5f5; color: #222; }
    h1 { font-size: 1.2em; margin-bottom: 4px; }
    .subtitle { font-size: 0.9em; color: #555; margin-bottom: 28px; }
    .install-box { background: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 24px 28px; max-width: 620px; margin-bottom: 32px; }
    .install-box h2 { font-size: 1em; margin: 0 0 12px 0; }
    .install-box ol { margin: 0; padding-left: 20px; line-height: 1.8; font-size: 0.95em; }
    .drag-target { display: inline-block; margin: 18px 0 6px 0; padding: 10px 22px; background: #1a73e8; color: #fff; border-radius: 6px; font-size: 1em; font-weight: bold; text-decoration: none; cursor: grab; }
    .drag-target:hover { background: #1558b0; }
    .note { font-size: 0.82em; color: #777; margin-top: 4px; }
    .payload-box { background: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 24px 28px; max-width: 620px; }
    .payload-box h2 { font-size: 1em; margin: 0 0 12px 0; }
    .payload-box p { font-size: 0.9em; color: #555; margin: 0 0 14px 0; }
    details summary { cursor: pointer; font-size: 0.95em; font-weight: bold; color: #1a73e8; margin-bottom: 10px; }
    pre { background: #f8f8f8; border: 1px solid #e0e0e0; border-radius: 4px; padding: 14px; font-size: 0.8em; overflow-x: auto; white-space: pre; }
    .warning { background: #fff8e1; border: 1px solid #ffe082; border-radius: 6px; padding: 12px 16px; font-size: 0.88em; color: #5d4200; margin-bottom: 20px; max-width: 620px; }
  </style>
</head>
<body>

  <h1>Listing Info Bookmarklet</h1>
  <p class="subtitle">Tab 1 of 12 · Cascade dropdowns · Three entry paths (New / Tax ID / Copy) · Universal — no builder logic</p>

  <div class="warning">
    ⚠️ <strong>Timing note:</strong> This bookmarklet fires two cascade change events with async delays (1500ms + 800ms). After clicking, wait ~3 seconds before touching the page — the dependent dropdowns (Area, ZIP, Subdivision, Schools) need time to repopulate from the server.
  </div>

  <div class="install-box">
    <h2>Install</h2>
    <ol>
      <li>Show the Chrome bookmarks bar: <strong>Cmd+Shift+B</strong></li>
      <li>Drag the button below to the correct folder on your bookmarks bar:<br>
          <strong>Matrix — New</strong>, <strong>Matrix — Tax ID</strong>, or <strong>Matrix — Copy</strong></li>
      <li>Name it <strong>Listing Info</strong></li>
    </ol>
    <a class="drag-target" href="javascript:(function()%20%7Bfunction%20setField(id%2C%20value)%20%7Bvar%20el%20%3D%20document.getElementById(id)%3Bif%20(el)%20%7B%20el.value%20%3D%20value%3B%20%7D%7Dfunction%20fireChange(id)%20%7Bvar%20el%20%3D%20document.getElementById(id)%3Bif%20(el)%20%7B%20el.dispatchEvent(new%20Event('change'%2C%20%7Bbubbles%3A%20true%7D))%3B%20%7D%7Dfunction%20wait(ms)%20%7Breturn%20new%20Promise(function(resolve)%20%7B%20setTimeout(resolve%2C%20ms)%3B%20%7D)%3B%7Dnavigator.clipboard.readText().then(function(text)%20%7Bvar%20payload%20%3D%20JSON.parse(text)%3Bvar%20d%20%3D%20payload.listing%3Bvar%20path%20%3D%20payload.path%20%7C%7C%20%22new%22%3B(async%20function()%20%7BsetField('Input_29'%2C%20d.county_city)%3BfireChange('Input_29')%3Bawait%20wait(1500)%3BsetField('Input_30'%2C%20d.area)%3BfireChange('Input_30')%3Bawait%20wait(800)%3BsetField('Input_635'%2C%20d.zip)%3BsetField('Input_259'%2C%20d.subdivision)%3BsetField('Input_236'%2C%20d.neighborhood)%3BsetField('Input_51'%2C%20d.elementary)%3BsetField('Input_53'%2C%20d.middle)%3BsetField('Input_52'%2C%20d.high)%3BsetField('Input_41'%2C%20d.post_office)%3BsetField('Input_32'%2C%20d.delayed_show)%3BsetField('Input_42'%2C%20d.new_resale)%3BsetField('Input_45'%2C%20d.year_built_desc)%3BsetField('Input_162'%2C%20d.expire_date)%3BsetField('Input_97'%2C%20d.sqft_source%20%7C%7C%20%2201%22)%3BsetField('Input_31'%2C%20d.list_price)%3BsetField('Input_160'%2C%20d.list_date)%3BsetField('Input_849'%2C%20d.type)%3BsetField('Input_850'%2C%20d.attached_yn)%3Bif%20(path%20%3D%3D%3D%20%22new%22)%20%7BsetField('Input_99'%2C%20d.pid%20%7C%7C%20'TBD')%3B%7DsetField('Input_35'%2C%20d.street_dir%20%7C%7C%20%22%22)%3Bif%20(path%20%3D%3D%3D%20%22new%22)%20%7BsetField('Input_34'%2C%20d.street_num)%3BsetField('Input_36'%2C%20d.street_name)%3BsetField('Input_37'%2C%20d.street_suffix)%3B%7Dif%20(path%20!%3D%3D%20%22taxid%22)%20%7BsetField('Input_44'%2C%20d.year_built)%3BsetField('Input_48'%2C%20d.rooms)%3BsetField('Input_49'%2C%20d.levels)%3BsetField('Input_622'%2C%20d.lot)%3BsetField('Input_47'%2C%20d.bedrooms)%3B%7DsetField('Input_879'%2C%20d.sqft_above_finished%20%7C%7C%20%220%22)%3BsetField('Input_882'%2C%20d.sqft_below_finished%20%7C%7C%20%220%22)%3BsetField('Input_880'%2C%20d.sqft_above_unfinished%20%7C%7C%20%220%22)%3BsetField('Input_883'%2C%20d.sqft_below_unfinished%20%7C%7C%20%220%22)%3B%7D)()%3B%7D).catch(function(e)%20%7Balert('Bookmarklet%20error%20%E2%80%94%20could%20not%20read%20clipboard%3A%20'%20%2B%20e.message)%3B%7D)%3B%7D)()%3B">Listing Info</a>
    <p class="note">Drag the blue button to your bookmarks bar — do not click it here.</p>
  </div>

  <div class="payload-box">
    <h2>Payload Reference — <code>listing</code> key</h2>
    <p>The session outputs one full JSON object per listing. This bookmarklet reads the <code>listing</code> key only. Every value — including community-derived ones like county/city, zip, subdivision, and schools — is already resolved by the session before the payload is copied. The bookmarklet has no builder awareness; it just writes what is in the payload.</p>

    <details>
      <summary>Show example payload</summary>
      <pre>{
  "path": "new",
  "listing": {
    "county_city":           "Chesterfield",
    "area":                  "54",
    "zip":                   "23832",
    "subdivision":           "Harpers Mill",
    "neighborhood":          "",
    "elementary":            "Winterpock",
    "middle":                "DeepCreek",
    "high":                  "Cosby",
    "post_office":           "Chesterfield",
    "delayed_show":          "0",
    "new_resale":            "NVROC",
    "year_built_desc":       "UNDCON",
    "expire_date":           "12/31/2026",
    "sqft_source":           "04",
    "list_price":            "424990",
    "list_date":             "06/25/2026",
    "type":                  "TOWN",
    "attached_yn":           "1",
    "pid":                   "TBD",
    "street_num":            "8752",
    "street_dir":            "",
    "street_name":           "Whitman",
    "street_suffix":         "DR",
    "year_built":            "2026",
    "rooms":                 "6",
    "levels":                "3",
    "lot":                   "42",
    "bedrooms":              "3",
    "sqft_above_finished":   "1680",
    "sqft_below_finished":   "0",
    "sqft_above_unfinished": "0",
    "sqft_below_unfinished": "0"
  }
}</pre>
    </details>

    <details>
      <summary>Show fields filled by this bookmarklet</summary>
      <pre>ALWAYS — from payload (no builder gate):
  Input_29  — County/City        → fires cascade
  Input_30  — Area               → fires cascade
  Input_635 — ZIP Code
  Input_259 — Subdivision
  Input_236 — Neighborhood
  Input_51  — Elementary School
  Input_53  — Middle School
  Input_52  — High School
  Input_41  — Post Office
  Input_32  — Delayed Show
  Input_42  — New/Resale
  Input_45  — Year Built Desc
  Input_162 — Expire Date
  Input_97  — SqFt Source        → defaults to "01" if not in payload
  Input_31  — List Price
  Input_160 — List Date
  Input_849 — Type
  Input_850 — Attached Y/N
  Input_35  — Street Direction   → always writes regardless of path
  Input_879 — SqFt Above Finished
  Input_882 — SqFt Below Finished
  Input_880 — SqFt Above Unfinished
  Input_883 — SqFt Below Unfinished

FROM PAYLOAD — New path only (pre-filled on taxid/copy paths):
  Input_99  — PID/Tax ID         → falls back to "TBD" if not in payload
  Input_34  — Street Number
  Input_36  — Street Name
  Input_37  — Street Suffix

FROM PAYLOAD — non-taxid paths only (pre-populated on taxid path):
  Input_44  — Year Built
  Input_48  — Rooms
  Input_49  — Levels
  Input_622 — Lot
  Input_47  — Bedrooms

ALWAYS MANUAL:
  Latitude, Longitude, Directions</pre>
    </details>

    <p style="font-size:12px;color:#888;margin-top:14px;">Community-derived fields (county/city, area, zip, subdivision, neighborhood, schools, post office) and statics (delayed show, new/resale, year built desc, expire date, sqft source) are resolved by the session per builder before the payload is generated — see <code>Lennar_Bookmarklet_Customization.md</code> for the Lennar community lookup table and statics reference.</p>
  </div>

  <div class="note" style="margin-top:24px;">AAR-TC-CVRMLS-BM-SRC-001 | Source: CVRMLS_Bookmarklet_Source.md</div>

</body>
</html>
```

No other changes to `bookmarklets/listing_info.html`.

Do not commit yet. Changes for additional files follow in separate handoffs.
