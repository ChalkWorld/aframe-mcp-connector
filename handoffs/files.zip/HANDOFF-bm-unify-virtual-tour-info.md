---
title: Cursor Handoff — bookmarklets/virtual_tour_info.html — Bookmarklet Unification
document_id: HANDOFF-bm-unify-virtual-tour-info
date: 2026-06-30
project: AAR-TC CVRMLS Matrix Bookmarklet
---

Replace the entire contents of `bookmarklets/virtual_tour_info.html` with the file below. This is a full-file replacement, not a partial edit — the existing file contains Lennar-specific logic that this version removes entirely.

## Change 1 — Replace full file contents

**Add** (replacing the entire current contents of `bookmarklets/virtual_tour_info.html`):

```html
<!DOCTYPE html>
<html>
<head>
  <title>Matrix — Virtual Tour Info</title>
  <style>
    body { font-family: sans-serif; max-width: 600px; margin: 60px auto; padding: 0 20px; color: #333; }
    h2 { margin-bottom: 4px; }
    .tab-label { font-size: 12px; font-weight: bold; letter-spacing: 0.08em; text-transform: uppercase; color: #1a73e8; margin-bottom: 16px; }
    p { margin-top: 4px; color: #666; font-size: 14px; }
    a.bookmarklet { display: inline-block; margin: 20px 0; padding: 14px 28px; background: #1a73e8; color: white; text-decoration: none; border-radius: 6px; font-size: 16px; font-weight: bold; }
    a.bookmarklet:hover { background: #1558b0; }
    .instructions { background: #f5f5f5; border-left: 4px solid #1a73e8; padding: 16px 20px; border-radius: 4px; font-size: 14px; line-height: 1.8; margin-top: 8px; }
    .warning { background: #fff8e1; border-left: 4px solid #f9a825; padding: 12px 16px; border-radius: 4px; font-size: 13px; margin-top: 20px; line-height: 1.7; }
    .payload-label { font-size: 13px; font-weight: bold; color: #555; margin: 28px 0 6px 0; }
    .payload { background: #1e1e1e; color: #d4d4d4; padding: 16px 20px; border-radius: 4px; font-size: 12px; font-family: monospace; white-space: pre; margin-bottom: 8px; }
    .note { font-size: 12px; color: #888; margin-top: 24px; }
  </style>
</head>
<body>

  <div class="tab-label">Tab 11 — Virtual Tour Info</div>
  <h2>Fill Virtual Tour Info</h2>
  <p>Universal — was already builder-agnostic. No JS change; retitled only.</p>

  <a class="bookmarklet" href="javascript:(function()%20%7Bfunction%20setField(id%2C%20value)%20%7Bvar%20el%20%3D%20document.getElementById(id)%3Bif%20(el)%20%7B%20el.value%20%3D%20value%3B%20%7D%7Dnavigator.clipboard.readText().then(function(text)%20%7Bvar%20d%20%3D%20JSON.parse(text).tour%3BsetField('Input_610'%2C%20d.virtual_tour%20%7C%7C%20%22%22)%3BsetField('Input_611'%2C%20d.additional_virtual_tour%20%7C%7C%20%22%22)%3B%7D).catch(function(e)%20%7Balert('Virtual%20Tour%20error%3A%20'%20%2B%20e.message)%3B%7D)%3B%7D)()%3B">Fill Virtual Tour Info</a>

  <div class="instructions">
    <strong>To install:</strong><br>
    1. Make bookmarks bar visible — Cmd+Shift+B<br>
    2. Drag the blue button to the bookmarks bar<br>
    3. Place in the <strong>Matrix — New</strong>, <strong>Matrix — Tax ID</strong>, or <strong>Matrix — Copy</strong> folder<br><br>
    <strong>To use:</strong><br>
    1. Copy the full JSON payload to clipboard<br>
    2. Navigate to the Virtual Tour Info tab in Matrix<br>
    3. Click the bookmark — URL(s) populate from clipboard
  </div>

  <div class="warning">
    ⚠️ <strong>Skip this tab entirely</strong> if no virtual tour link was provided in the listing source. Do not navigate to or click this bookmark for listings without a tour URL.
  </div>

  <div class="payload-label">Payload reference — tour key</div>
  <div class="payload">"tour": {
  "virtual_tour": "https://...",
  "additional_virtual_tour": ""
}</div>

  <div class="note">AAR-TC-CVRMLS-BM-SRC-001 | Source: CVRMLS_Bookmarklet_Source.md</div>

</body>
</html>
```

No other changes to `bookmarklets/virtual_tour_info.html`.

Do not commit yet. Changes for additional files follow in separate handoffs.
