---
title: Cursor Handoff — bookmarklets/general_info.html — Bookmarklet Unification
document_id: HANDOFF-bm-unify-general-info
date: 2026-06-30
project: AAR-TC CVRMLS Matrix Bookmarklet
---

Replace the entire contents of `bookmarklets/general_info.html` with the file below. This is a full-file replacement, not a partial edit — the existing file contains Lennar-specific logic that this version removes entirely.

## Change 1 — Replace full file contents

**Add** (replacing the entire current contents of `bookmarklets/general_info.html`):

```html
<!DOCTYPE html>
<html>
<head>
  <title>Matrix — General Info</title>
  <style>
    body { font-family: sans-serif; max-width: 600px; margin: 60px auto; padding: 0 20px; color: #333; }
    h2 { margin-bottom: 4px; }
    .tab-label { font-size: 12px; font-weight: bold; letter-spacing: 0.08em; text-transform: uppercase; color: #1a73e8; margin-bottom: 16px; }
    p { margin-top: 4px; color: #666; font-size: 14px; }
    a.bookmarklet { display: inline-block; margin: 20px 0; padding: 14px 28px; background: #1a73e8; color: white; text-decoration: none; border-radius: 6px; font-size: 16px; font-weight: bold; }
    a.bookmarklet:hover { background: #1558b0; }
    .instructions { background: #f5f5f5; border-left: 4px solid #1a73e8; padding: 16px 20px; border-radius: 4px; font-size: 14px; line-height: 1.8; margin-top: 8px; }
    .warning { background: #fff8e1; border-left: 4px solid #f9a825; padding: 12px 16px; border-radius: 4px; font-size: 13px; margin-top: 12px; line-height: 1.7; }
    .payload-label { font-size: 13px; font-weight: bold; color: #555; margin: 28px 0 6px 0; }
    .payload { background: #1e1e1e; color: #d4d4d4; padding: 16px 20px; border-radius: 4px; font-size: 12px; font-family: monospace; white-space: pre; margin-bottom: 8px; }
    .note { font-size: 12px; color: #888; margin-top: 24px; }
  </style>
</head>
<body>

  <div class="tab-label">Tab 5 — General Info</div>
  <h2>Fill General Info</h2>
  <p>Universal — fully payload-driven. No builder branch; Assd Improvement, Disclosures, and Lead Disclosure are resolved by the session before the payload is generated.</p>

  <a class="bookmarklet" href="javascript:(function()%20%7Bfunction%20setField(id%2C%20value)%20%7Bvar%20el%20%3D%20document.getElementById(id)%3Bif%20(el)%20%7B%20el.value%20%3D%20value%3B%20%7D%7Dfunction%20setCheck(id%2C%20checked)%20%7Bvar%20el%20%3D%20document.getElementById(id)%3Bif%20(el)%20%7B%20el.checked%20%3D%20checked%3B%20%7D%7Dnavigator.clipboard.readText().then(function(text)%20%7Bvar%20payload%20%3D%20JSON.parse(text)%3Bvar%20d%20%3D%20payload.general%3Bvar%20path%20%3D%20payload.path%20%7C%7C%20%22new%22%3BsetField('Input_249'%2C%20d.model_available%20%7C%7C%20%220%22)%3BsetField('Input_94'%2C%20d.waterfront%20%7C%7C%20%22N%22)%3BsetField('Input_248'%2C%20d.assd_improvement%20%7C%7C%20%220%22)%3Bvar%20disclosureIds%20%3D%20%5B'LISTAT'%2C'NOFORM'%2C'NOTREQ'%2C'OFFICE'%2C'PROPTY'%2C'APZ1'%2C'APZ2'%2C'LESS65'%2C'75PLUS'%2C'65TO70'%2C'70TO75'%2C'POTCLZ'%5D%3BdisclosureIds.forEach(function(v)%20%7B%20setCheck('Input_102_'%20%2B%20v%2C%20false)%3B%20%7D)%3B(d.disclosures%20%7C%7C%20%5B%5D).forEach(function(v)%20%7B%20setCheck('Input_102_'%20%2B%20v%2C%20true)%3B%20%7D)%3Bvar%20leadIds%20%3D%20%5B'LISTAT'%2C'NOFORM'%2C'NOTREQ'%2C'OFFICE'%2C'PROPTY'%5D%3BleadIds.forEach(function(v)%20%7B%20setCheck('Input_103_'%20%2B%20v%2C%20false)%3B%20%7D)%3B(d.lead_disclosure%20%7C%7C%20%5B%5D).forEach(function(v)%20%7B%20setCheck('Input_103_'%20%2B%20v%2C%20true)%3B%20%7D)%3Bif%20(path%20%3D%3D%3D%20%22new%22)%20%7BsetField('Input_246'%2C%20d.tax_year%20%7C%7C%20%220%22)%3BsetField('Input_95'%2C%20d.acres%20%7C%7C%20%22%22)%3BsetField('Input_100'%2C%20d.legal%20%7C%7C%20%22%22)%3B%7DsetField('Input_697'%2C%20d.investor_rental_cap%20%7C%7C%20%22%22)%3BsetField('Input_700'%2C%20d.water_depth%20%7C%7C%20%22%22)%3BsetField('Input_250'%2C%20d.model_furnished%20%7C%7C%20%22%22)%3BsetField('Input_703'%2C%20d.energy_efficient%20%7C%7C%20%22%22)%3BsetField('Input_702'%2C%20d.pre_qual_letter%20%7C%7C%20%22%22)%3BsetField('Input_696'%2C%20d.body_of_water%20%7C%7C%20%22%22)%3BsetField('Input_96'%2C%20d.lot_dimensions%20%7C%7C%20%22%22)%3B%7D).catch(function(e)%20%7Balert('General%20Info%20error%3A%20'%20%2B%20e.message)%3B%7D)%3B%7D)()%3B">Fill General Info</a>

  <div class="instructions">
    <strong>To install:</strong><br>
    1. Make bookmarks bar visible — Cmd+Shift+B<br>
    2. Drag the blue button to the bookmarks bar<br>
    3. Place in the <strong>Matrix — New</strong>, <strong>Matrix — Tax ID</strong>, or <strong>Matrix — Copy</strong> folder<br><br>
    <strong>To use:</strong><br>
    1. Copy the full JSON payload to clipboard<br>
    2. Navigate to the General Info tab in Matrix<br>
    3. Click the bookmark — all fields populate from the payload; Tax Year, Acres, and Legal Description are skipped automatically on the Tax ID path
  </div>

  <div class="warning">
    ⚠️ <strong>Assd Improvement (Input_248):</strong> No builder branch — the bookmarklet always writes whatever value is in the payload, falling back to <code>"0"</code> if the key is missing. For a standard taxid listing where Matrix has already pre-populated this field from the tax record, the session must omit <code>assd_improvement</code> from the payload entirely (not send an empty string) — otherwise this bookmarklet's fallback will overwrite the pre-populated value with <code>"0"</code>.<br><br>
    ⚠️ <strong>Tax ID path:</strong> Tax Year, Acres, and Legal Description are pre-populated from the tax record on taxid path — bookmarklet skips all three automatically based on <code>payload.path</code>.
  </div>

  <div class="payload-label">Payload reference — general key</div>
  <div class="payload">"general": {
  "model_available":     "0",
  "waterfront":           "N",
  "assd_improvement":    "0",      // omit this key entirely on standard taxid listings
  "disclosures":          ["NOTREQ"],
  "lead_disclosure":      ["NOTREQ"],
  "tax_year":             "0",     // New path only
  "acres":                "0.14",  // New path only
  "legal":                "TBD"    // New path only
}</div>

  <p style="font-size:12px;color:#888;margin-top:4px;">Resolved by the session per builder before the payload is generated — see <code>Lennar_Bookmarklet_Customization.md</code> for Lennar statics.</p>

  <div class="note">AAR-TC-CVRMLS-BM-SRC-001 | Source: CVRMLS_Bookmarklet_Source.md</div>

</body>
</html>
```

No other changes to `bookmarklets/general_info.html`.

Do not commit yet. Changes for additional files follow in separate handoffs.
