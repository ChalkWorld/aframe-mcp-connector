---
title: Cursor Handoff — docs/lennar/Lennar_Features_Bookmarklet_Source.md — Bookmarklet Unification
document_id: HANDOFF-bm-unify-lennar-features-source
date: 2026-06-30
project: AAR-TC CVRMLS Matrix Bookmarklet
---

Apply the change below surgically to `docs/lennar/Lennar_Features_Bookmarklet_Source.md`. Do not modify anything not listed here.

**Note on this handoff's Find block:** unlike the other handoffs in this batch, this session did not have direct sight of this file's current full text — only its opening section (document ID, version header, and the "TAB 4 — Features" intro paragraph) via prior search results. If the Find block below does not match exactly, locate the section titled "### Features — Lennar Variant" (or equivalent — the section containing the Lennar-specific JavaScript function with the `COMMUNITIES`/`C` lookup table and `isLennar`-equivalent static writes) and replace that entire section, from its header through the end of its closing ```` ``` ```` code fence, with the **Replace with** content below. Do not guess at surrounding content beyond that section.

## Change 1 — Replace the Lennar Features variant section with the resolution table

**Find:**

```markdown
### Features — Lennar Variant
```

**Replace with:**

```markdown
### Features — Lennar Resolution

**No separate Lennar bookmarklet.** `bookmarklets/lennar_features.html` is deleted (see companion deletion handoff). `bookmarklets/features_a.html` and `bookmarklets/features_b.html` are the only Features launchers, used for every listing regardless of builder. Confirmed this session: every checkbox-group field shared between the former Lennar launcher and Features A/B was byte-identical — same Input IDs, same order, across all twelve shared groups (style, parking, exterior, interior, fireplace, community_amenities, pool_desc, appl_equip, heating, heat_fuel, porch, unit_placement). Features A/B were already correctly built as the canonical universal source; the Lennar launcher was a correct derivation of it, just kept as a separate file unnecessarily.

The session resolves every Lennar-specific value below into the `features_a` / `features_b` payload keys before generating the payload. The bookmarklet has no builder awareness anywhere in this tab.

#### Pure statics (11 fields) — session resolves to a fixed value; no bookmarklet logic involved

| Field | Payload key | Lennar value |
|---|---|---|
| Structure | `features_a.structure` | `["Input_70_03"]` (Frame) |
| Siding | `features_a.siding` | `["Input_71_22"]` (Vinyl) |
| Roof | `features_a.roof` | `["Input_72_12"]` (Shingled) |
| Flooring | `features_a.flooring` | `["Input_73_17"]` (Vinyl - Plank/Tile/Stone) |
| Attic | `features_a.attic` | `["Input_241_09"]` (Access Panel) |
| Golf Frontage Y/N | `features_a.golf_frontage_yn` | `"0"` |
| Water | `features_a.water` | `["Input_676_PW"]` (Public Water) |
| Sewer/Septic | `features_a.sewer` | `["Input_670_PBLCSR"]` (Sewer - Public) |
| Water Heater | `features_b.water_heater` | `["Input_571_01"]` (Electric) |
| Cooling | `features_b.cooling` | `["Input_88_06"]` (Heat Pump) |
| Wall Type | `features_b.wall_type` | `["Input_254_02"]` (Drywall) |

#### Community-lookup (5 fields) — session resolves via the community table below

| Field | Payload key |
|---|---|
| Heating | `features_b.heating` |
| Heat Fuel | `features_b.heat_fuel` |
| Pool Y/N | `features_b.pool_yn` |
| Pool Description | `features_b.pool_desc` (conditional on Pool Y/N = `"1"`) |
| Community Amenities | `features_b.community_amenities` |

**Confirmed community table** (matches the five community keys in `Lennar_Bookmarklet_Customization.md`):

```
Harpers Mill TH:  heating ["Input_86_07"], heat_fuel ["Input_87_05"], pool_yn "1",
                  pool_desc ["Input_91_02"],
                  community_amenities ["Input_534_01","Input_534_03","Input_534_04","Input_534_22","Input_534_47"]
Harpers Mill SF:  identical to Harpers Mill TH
Creekside Run:    heating ["Input_86_08"], heat_fuel ["Input_87_02"], pool_yn "0", pool_desc [],
                  community_amenities ["Input_534_01","Input_534_04","Input_534_46","Input_534_22"]
Everstone:        identical to Creekside Run
Watermark:        heating ["Input_86_07"], heat_fuel ["Input_87_05"], pool_yn "1",
                  pool_desc ["Input_91_02"], community_amenities ["Input_534_01"]
```

#### Conditional-on-payload-value (not builder-specific — no bookmarklet change needed)

| Field | Payload key | Resolution |
|---|---|---|
| Garage | `features_a.garage` | Session resolves to `["Input_539_02","Input_539_05"]` (Attached + Direct Entry) when `garage_yn === "1"`, plus `"Input_539_03"` (Auto Door Opener) if applicable, or `[]` if no garage. Features A's existing `setCheckGroup(ids, d.garage)` already accepts any array — no new payload key, no bookmarklet conditional logic needed. |
| Basement/Foundation | `features_a.basement_foundation` | Session resolves to `["Input_569_03"]` (Crawl Space) if `basement_yn === "1"`, else `["Input_569_12"]` (Slab). |

#### Already shared, no resolution needed — listing-specific regardless of builder

Style, Parking, Exterior, Interior, Appl/Equip, Porch, Num Cars, Num Fp, Fireplace (Features A already implements the conditional-on-`num_fp > 0` check for this field).

**Net effect: zero changes to `bookmarklets/features_a.html` or `bookmarklets/features_b.html`.** The entire merge is session-side payload resolution.
```

No other changes to `docs/lennar/Lennar_Features_Bookmarklet_Source.md`.

Do not commit yet. The deletion handoff for `bookmarklets/lennar_features.html` follows, and is the last handoff in this sequence — it contains the commit block.
