---
title: Cursor Handoff — bookmarklets/owner_info.html — Bookmarklet Unification
document_id: HANDOFF-bm-unify-owner-info
date: 2026-06-30
project: AAR-TC CVRMLS Matrix Bookmarklet
---

Replace the entire contents of `bookmarklets/owner_info.html` with the file below. This is a full-file replacement, not a partial edit — the existing file contains Lennar-specific logic that this version removes entirely.

## Change 1 — Replace full file contents

**Add** (replacing the entire current contents of `bookmarklets/owner_info.html`):

```html
<!DOCTYPE html>
<html>
<head>
  <title>Matrix — Owner Info</title>
  <style>
    body { font-family: sans-serif; max-width: 600px; margin: 60px auto; padding: 0 20px; color: #333; }
    h2 { margin-bottom: 4px; }
    .tab-label { font-size: 12px; font-weight: bold; letter-spacing: 0.08em; text-transform: uppercase; color: #1a73e8; margin-bottom: 16px; }
    p { margin-top: 4px; color: #666; font-size: 14px; }
    a.bookmarklet { display: inline-block; margin: 20px 0; padding: 14px 28px; background: #1a73e8; color: white; text-decoration: none; border-radius: 6px; font-size: 16px; font-weight: bold; }
    a.bookmarklet:hover { background: #1558b0; }
    .instructions { background: #f5f5f5; border-left: 4px solid #1a73e8; padding: 16px 20px; border-radius: 4px; font-size: 14px; line-height: 1.8; margin-top: 8px; }
    .warning { background: #fff8e1; border-left: 4px solid #f9a825; padding: 12px 16px; border-radius: 4px; font-size: 13px; margin-top: 12px; line-height: 1.7; }
    .payload-label { font-size: 13px; font-weight: bold; color: #555; margin: 28px 0 6px 0; }
    .payload { background: #1e1e1e; color: #d4d4d4; padding: 16px 20px; border-radius: 4px; font-size: 12px; font-family: monospace; white-space: pre; margin-bottom: 8px; }
    .note { font-size: 12px; color: #888; margin-top: 24px; }
  </style>
</head>
<body>

  <div class="tab-label">Tab 8 — Owner Info</div>
  <h2>Fill Owner Info</h2>
  <p>Universal — fully payload-driven, including the Owner Name field. No builder branch — the bookmarklet writes whatever the session provides, or leaves Matrix's pre-populated value alone if the key is omitted.</p>

  <a class="bookmarklet" href="javascript:(function()%20%7Bfunction%20setField(id%2C%20value)%20%7Bvar%20el%20%3D%20document.getElementById(id)%3Bif%20(el)%20%7B%20el.value%20%3D%20value%3B%20%7D%7Dfunction%20setCheck(id%2C%20checked)%20%7Bvar%20el%20%3D%20document.getElementById(id)%3Bif%20(el)%20%7B%20el.checked%20%3D%20checked%3B%20%7D%7Dnavigator.clipboard.readText().then(function(text)%20%7Bvar%20d%20%3D%20JSON.parse(text).owner%20%7C%7C%20%7B%7D%3Bif%20(d.owner_name%20!%3D%3D%20undefined)%20%7BsetField('Input_118'%2C%20d.owner_name)%3B%7DsetField('Input_119'%2C%20d.occupant_name%20%7C%7C%20%22%22)%3BsetField('Input_606'%2C%20d.occupied_by%20%7C%7C%20%22%22)%3BsetField('Input_124'%2C%20d.owner_agent%20%7C%7C%20%220%22)%3BsetField('Input_707'%2C%20d.agent_related_to_seller%20%7C%7C%20%220%22)%3Bvar%20ownedByIds%20%3D%20%5B'02'%2C'03'%2C'04'%2C'06'%2C'07'%2C'08'%2C'01'%5D%3BownedByIds.forEach(function(v)%20%7B%20setCheck('Input_120_'%20%2B%20v%2C%20false)%3B%20%7D)%3Bif%20(d.owned_by)%20%7B%20setCheck('Input_120_'%20%2B%20d.owned_by%2C%20true)%3B%20%7Dvar%20possessionIds%20%3D%20%5B'01'%2C'02'%2C'06'%2C'03'%2C'04'%2C'05'%5D%3BpossessionIds.forEach(function(v)%20%7B%20setCheck('Input_121_'%20%2B%20v%2C%20false)%3B%20%7D)%3Bif%20(d.possession)%20%7B%20setCheck('Input_121_'%20%2B%20d.possession%2C%20true)%3B%20%7D%7D).catch(function(e)%20%7Balert('Owner%20Info%20error%3A%20'%20%2B%20e.message)%3B%7D)%3B%7D)()%3B">Fill Owner Info</a>

  <div class="instructions">
    <strong>To install:</strong><br>
    1. Make bookmarks bar visible — Cmd+Shift+B<br>
    2. Drag the blue button to the bookmarks bar<br>
    3. Place in the <strong>Matrix — New</strong>, <strong>Matrix — Tax ID</strong>, or <strong>Matrix — Copy</strong> folder<br><br>
    <strong>To use:</strong><br>
    1. Copy the full JSON payload to clipboard<br>
    2. Navigate to the Owner Info tab in Matrix<br>
    3. Click the bookmark — fields populate from the payload
  </div>

  <div class="warning">
    ⚠️ <strong>Owner Name (Input_118) — unconditional write, no taxid skip.</strong> Unlike most fields on this tab, the bookmarklet writes Owner Name whenever <code>owner_name</code> is present in the payload — regardless of path. This matches Lennar's force-overwrite behavior, but the bookmarklet has no idea it's Lennar; it's just following the payload. For a standard taxid listing where Matrix's tax-record owner name should be left alone, the session must omit the <code>owner_name</code> key entirely from the payload.<br><br>
    ⚠️ <strong>Open design question carried from the unification session:</strong> whether standard listings ever need an Owner Name override resolved the same way Lennar's force-overwrite works, or whether this field stays Lennar-only in practice. Not resolved here — flagged for the session to decide when it's relevant.
  </div>

  <div class="payload-label">Payload reference — owner key</div>
  <div class="payload">"owner": {
  "owner_name":              "Lennar",   // omit this key entirely to leave Matrix's
                                          // pre-populated taxid value untouched
  "occupant_name":           "None",
  "occupied_by":              "V",       // e.g. "V" (Vacant)
  "owner_agent":              "0",
  "agent_related_to_seller":  "0",
  "owned_by":                 "02",      // checkbox value — e.g. "02" (Corporate)
  "possession":               "01"       // checkbox value — e.g. "01" (At Closing)
}</div>

  <p style="font-size:12px;color:#888;margin-top:4px;">Resolved by the session per builder before the payload is generated — see <code>Lennar_Bookmarklet_Customization.md</code> for the Lennar fully-static block.</p>

  <div class="note">AAR-TC-CVRMLS-BM-SRC-001 | Source: CVRMLS_Bookmarklet_Source.md</div>

</body>
</html>
```

No other changes to `bookmarklets/owner_info.html`.

Do not commit yet. Changes for additional files follow in separate handoffs.
