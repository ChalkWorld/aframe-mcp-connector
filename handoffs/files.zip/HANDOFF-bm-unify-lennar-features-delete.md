---
title: Cursor Handoff — bookmarklets/lennar_features.html — Deletion
document_id: HANDOFF-bm-unify-lennar-features-delete
date: 2026-06-30
project: AAR-TC CVRMLS Matrix Bookmarklet
---

Delete `bookmarklets/lennar_features.html` from the repo. Apply surgically — do not modify any other files.

## Change 1 — Delete the file

This file is removed, not replaced. `bookmarklets/features_a.html` and `bookmarklets/features_b.html` were confirmed this session to already be fully universal and payload-driven — every checkbox-group field shared between `lennar_features.html` and Features A/B was confirmed byte-identical (same Input IDs, same order). `lennar_features.html`'s Lennar-specific values (statics and community lookup table) move to session-time resolution, documented in `docs/lennar/Lennar_Bookmarklet_Customization.md` and `docs/lennar/Lennar_Features_Bookmarklet_Source.md` — see the companion handoffs for those files.

**Delete:**

```bash
git rm bookmarklets/lennar_features.html
```

No other changes in this handoff.

This is the last handoff in the bookmarklet unification sequence. Delete all handoff files used this session, commit, and push:

```bash
git rm handoffs/HANDOFF-bm-unify-listing-info.md handoffs/HANDOFF-bm-unify-bath-info.md handoffs/HANDOFF-bm-unify-general-info.md handoffs/HANDOFF-bm-unify-fee-info.md handoffs/HANDOFF-bm-unify-agent-office-info.md handoffs/HANDOFF-bm-unify-showing-instructions.md handoffs/HANDOFF-bm-unify-owner-info.md handoffs/HANDOFF-bm-unify-remarks.md handoffs/HANDOFF-bm-unify-virtual-tour-info.md handoffs/HANDOFF-bm-unify-internet-display-info.md handoffs/HANDOFF-bm-unify-cvrmls-source.md handoffs/HANDOFF-bm-unify-lennar-customization.md handoffs/HANDOFF-bm-unify-lennar-features-source.md handoffs/HANDOFF-bm-unify-lennar-features-delete.md
git add -A
git commit -m "Bookmarklet unification: strip builder-specific logic from all 12 Matrix tab launchers, delete lennar_features.html, reframe source docs as session-time resolution references"
git push origin main
```
